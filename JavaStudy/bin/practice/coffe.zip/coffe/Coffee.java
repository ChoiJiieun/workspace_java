package practice.coffe;

public class Coffee {
	String name;  // 음료명
	int price;  // 가격
	
	public Coffee(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}
}
